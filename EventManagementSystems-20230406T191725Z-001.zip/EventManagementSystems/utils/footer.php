<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <span class = "small footerSubtext">Event Management System</span>
                        
                    </p>

                    <p class = "footerSubtext2">
                        Dhaka, Bangladesh
                        &copy; Events Management, 2023.
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                        <img src = "images/facebook.png">
                        <img src = "images/twitter.png">
                        <img src = "images/googleplus.png">
                        <img src = "images/youtube.png">
                </div>
            </section>
        </div>
    </div>
</footer>